// MoveToTargetCommand.cs � generic for any CombatCharacter (Enemy or Hero)
using ClickMage.Stats;
using UnityEngine;
public class MoveToTargetCommand : ICommand<BaseCharacter>
{
    private readonly Targetable _target;
    private readonly CombatCharacter _attacker;
    private Collider _targetCollider;
    public bool IsComplete { get; private set; }
    public MoveToTargetCommand(Targetable target, CombatCharacter attacker)
    {
        _target = target;
        _attacker = attacker;
    }
    public void Start(BaseCharacter character)
    {
        if (_target == null || !_target.IsAlive)
        {
            IsComplete = true;
            return;
        }
        _targetCollider = _target.GetComponent<Collider>();
        character.SetDestination(GetDestination(character));
        character.StateMachine.ChangeState(new CharacterMovingState());
    }
    public void Tick(BaseCharacter character, float deltaTime)
    {
        if (_target == null || !_target.IsAlive)
        {
            IsComplete = true;
            character.StateMachine.ChangeState(new CharacterIdleState());
            return;
        }
        character.Agent.speed = character.GetStatValue(CommonStats.MoveSpeed);
        character.SetDestination(GetDestination(character));
        // Check distance to collider surface, not center
        float dist = GetDistanceToSurface(character.transform.position);
        if (dist <= _attacker.GetStatValue(CommonStats.AttackRange))
        {
            IsComplete = true;
            character.StopMoving();
            character.StateMachine.ChangeState(new CharacterIdleState());
        }
    }
    public void Cancel()
    {
        IsComplete = true;
    }
    private Vector3 GetDestination(BaseCharacter character)
    {
        if (_targetCollider == null)
            return _target.transform.position;
        return _targetCollider.ClosestPoint(character.transform.position);
    }
    private float GetDistanceToSurface(Vector3 from)
    {
        if (_targetCollider == null)
            return Vector3.Distance(from, _target.transform.position);
        Vector3 closestPoint = _targetCollider.ClosestPoint(from);
        return Vector3.Distance(from, closestPoint);
    }
}