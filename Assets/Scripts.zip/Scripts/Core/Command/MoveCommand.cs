// MoveCommand.cs
using System;
using UnityEngine;
using UnityEngine.AI;
public class MoveCommand : ICommand<BaseCharacter>
{
    private readonly Vector3 _destination;
    private readonly float _stoppingDistance;
    public event EventHandler CanExecuteChanged;
    public bool IsComplete { get; private set; }

    /// <summary>Exposed so callers (e.g. HeroCharacter) can remember where a player sent this unit.</summary>
    public Vector3 Destination => _destination;

    public MoveCommand(Vector3 destination, float stoppingDistance = 0.5f)
    {
        _destination = destination;
        _stoppingDistance = stoppingDistance;
    }
    public void Start(BaseCharacter character)
    {

        var agent = character.Agent;
        if (agent == null || !agent.isOnNavMesh)
        {
            Debug.LogWarning("[MoveCommand] Agent is not on NavMesh.");
            IsComplete = true;
            return;
        }
        float[] sampleRadii = { 1f, 3f, 6f, 10f };
        NavMeshHit hit;
        bool found = false;
        foreach (var radius in sampleRadii)
        {
            if (NavMesh.SamplePosition(_destination, out hit, radius, agent.areaMask))
            {
                agent.stoppingDistance = _stoppingDistance;
                character.SetDestination(hit.position);
                Debug.Log($"[MoveCommand] Sampled at radius {radius}, moving to {hit.position}");
                found = true;
                character.StateMachine.ChangeState(new CharacterMovingState());
                break;
            }
        }
        if (!found)
        {
            Debug.LogWarning($"[MoveCommand] Could not project {_destination} onto NavMesh after all attempts.");
            IsComplete = true;
        }
    }
    public void Tick(BaseCharacter character, float deltaTime)
    {
        var agent = character.Agent;
        if (agent.pathPending) return;
        if (!agent.hasPath)
        {
            IsComplete = true;
            character.StopMoving();
            character.StateMachine.ChangeState(new CharacterIdleState());
            return;
        }
        bool arrivedByDistance = agent.remainingDistance <= _stoppingDistance;
        bool agentStopped = agent.velocity.sqrMagnitude < 0.02f;
        if (arrivedByDistance && agentStopped)
        {
            IsComplete = true;
            character.StopMoving();
            character.StateMachine.ChangeState(new CharacterIdleState());
        }
    }
    public void Cancel()
    {
        IsComplete = true;
    }
}