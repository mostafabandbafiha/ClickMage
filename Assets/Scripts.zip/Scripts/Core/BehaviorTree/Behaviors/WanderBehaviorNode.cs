// WanderBehaviorNode.cs
using UnityEngine;

public class WanderBehaviorNode : IBehaviorNode<BaseCharacter>
{
    private const float WanderRadius = 6f;

    public bool Execute(BaseCharacter owner)
    {
        Vector2 randomCircle = Random.insideUnitCircle * WanderRadius;
        Vector3 target = owner.transform.position + new Vector3(randomCircle.x, 0, randomCircle.y);

        owner.GiveAutonomousCommand(new MoveCommand(target, 0.5f));
        //Debug.Log($"[WanderBehaviorNode] {owner.name} wandering to {target}");
        return true;
    }
}
