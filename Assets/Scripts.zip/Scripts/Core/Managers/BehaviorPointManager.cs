using System.Collections.Generic;
using UnityEngine;

public class BehaviorPointManager : MonoBehaviour
{
    public static BehaviorPointManager Instance { get; private set; }

    [SerializeField] private List<BehaviorPoint> _allPoints = new();

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    public BehaviorPoint GetRandomPoint(Vector3 nearPosition, float maxDistance = 50f)
    {
        var validPoints = new List<BehaviorPoint>();

        foreach (var point in _allPoints)
        {
            float dist = Vector3.Distance(nearPosition, point.Position);
            if (dist <= maxDistance)
                validPoints.Add(point);
        }

        return validPoints.Count > 0 ? validPoints[Random.Range(0, validPoints.Count)] : null;
    }

    public void RegisterPoint(BehaviorPoint point)
    {
        if (!_allPoints.Contains(point))
            _allPoints.Add(point);
    }

    public void UnregisterPoint(BehaviorPoint point)
    {
        _allPoints.Remove(point);
    }
}
