using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class RestPointManager : MonoBehaviour
{
    public static RestPointManager Instance { get; private set; }

    [Header("Rest Points")]
    [SerializeField] private List<RestPoint> _restPoints = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    /// <summary>Returns the nearest available rest point to a position, or null if none.</summary>
    public RestPoint GetNearestAvailable(Vector3 position)
    {
        RestPoint best = null;
        float minDist = float.MaxValue;

        foreach (var rp in _restPoints)
        {
            if (rp == null || !rp.HasFreeSpot()) continue;
            float dist = Vector3.Distance(position, rp.transform.position);
            if (dist < minDist)
            {
                minDist = dist;
                best = rp;
            }
        }

        return best;
    }

    /// <summary>All rest points, for debugging or UI.</summary>
    public IReadOnlyList<RestPoint> AllRestPoints => _restPoints;
}