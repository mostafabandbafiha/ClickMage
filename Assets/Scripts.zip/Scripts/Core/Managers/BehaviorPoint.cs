using UnityEngine;

public enum BehaviorPointType
{
    Wander,
    Sit,
    Stand
}

public class BehaviorPoint : MonoBehaviour
{
    [SerializeField] private BehaviorPointType pointType = BehaviorPointType.Wander;
    [SerializeField] private float radius = 1f;

    public BehaviorPointType PointType => pointType;
    public Vector3 Position => transform.position;
    public float Radius => radius;

    private void Start()
    {
        BehaviorPointManager.Instance?.RegisterPoint(this);
    }
    
    private void OnDestroy()
    {
        BehaviorPointManager.Instance?.UnregisterPoint(this);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = pointType switch
        {
            BehaviorPointType.Sit => Color.blue,
            BehaviorPointType.Stand => Color.green,
            _ => Color.yellow
        };
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
