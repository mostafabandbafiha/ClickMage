using UnityEngine;
using ClickMage.Animation;

public class CharacterAnimator : MonoBehaviour, IAnimatable
{
    [SerializeField] private Animator animator;

    public void PlayAnimation(string stateName)
    {
        animator.Play(stateName);
    }

    public void SetFloat(string param, float value)
    {
        animator.SetFloat(param, value);
    }

    public void SetBool(string param, bool value)
    {
        animator.SetBool(param, value);
    }

    public float GetClipLength(string stateName)
    {
        if (animator == null) return 0.5f;

        if (animator.runtimeAnimatorController is AnimatorOverrideController overrideController)
        {
            var clip = overrideController[stateName];
            if (clip != null) return clip.length;
        }

        return 0.5f;
    }

}
