﻿// HeroCharacter.cs
// A player-commandable hero that stays out at night and engages enemies automatically.
//
// Key differences from GathererCharacter / VillagerCharacter:
//   • StaysOutAtNight stat (> 0) suppresses the GoHome() call from HouseStructure.
//   • Has a house but goes home ONLY when the player explicitly commands it.
//   • Behavior tree: auto-attack enemies in aggro range → wander as fallback.
//   • Player right-clicks ground → MoveCommand (existing CameraController path).
//   • Player right-clicks enemy → ContextMenuManager opens menu; menu issues
//     AttackEnemyCommand, which overrides whatever the BT queued.

using ClickMage.Stats;

public class HeroCharacter : CombatCharacter
{
    protected override bool IsAutonomous => false;

    protected override BehaviorTree<BaseCharacter> BuildBehaviorTree()
    {
        return new BehaviorTree<BaseCharacter>(
            new SelectorNode<BaseCharacter>(
                new HeroSeekBehaviorNode(),  // 1. attack if enemy in range
                new WanderBehaviorNode()    // 2. wander randomly
                //new RestBehaviorNode()           // 3. idle fallback
            )
        );
    }

    public override void OnAttack()
    {
        if (CurrentTarget == null || !CurrentTarget.IsAlive) return;
        CurrentTarget.TakeDamage(GetStatValue(CommonStats.Damage), this);
    }

}
