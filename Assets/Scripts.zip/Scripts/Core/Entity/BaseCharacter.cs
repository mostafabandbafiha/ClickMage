﻿using UnityEngine;
using UnityEngine.AI;
using ClickMage.StateMachine;
using ClickMage.Animation;
using ClickMage.Entities;
using ClickMage.Stats;
using System.Collections.Generic;

public abstract class BaseCharacter : BaseEntity, ICommandable<BaseCharacter>
{
    // ── Inspector ─────────────────────────────────────────────────────────
    [SerializeField] private float rotationSpeed = 10f;

    [Header("Autonomous Behavior")]
    [SerializeField] private float playerControlTimeout = 30f;
    [SerializeField] private float behaviorTreeTickInterval = 3f;

    [Header("Movement Detection")]
    [SerializeField] private float movementThreshold = 0.1f;

    // ── Runtime ───────────────────────────────────────────────────────────
    private CommandQueue<BaseCharacter> _commandQueue;
    private bool _isPlayerControlled = false;
    private float _playerControlTimer = 0f;
    private float _behaviorTreeTimer = 0f;

    // ── Public API ────────────────────────────────────────────────────────
    public float RotationSpeed => rotationSpeed;
    public bool IsPlayerControlled => _isPlayerControlled;

    public NavMeshAgent Agent { get; private set; }
    public CommandQueue<BaseCharacter> CommandQueue => _commandQueue;
    public IAnimatable Animator { get; private set; }
    public StateMachine<BaseCharacter> StateMachine { get; private set; }
    public Vector3 TargetPosition { get; set; }
    public Targetable Targetable { get; private set; }

    protected virtual BehaviorTree<BaseCharacter> BuildBehaviorTree() => null;

    /// <summary>
    /// Override to true in fully autonomous characters (enemies).
    /// Bypasses the player-control timer so the behavior tree always runs.
    /// </summary>
    protected virtual bool IsAutonomous => false;

    private BehaviorTree<BaseCharacter> _behaviorTree;

    // ── Unity lifecycle ───────────────────────────────────────────────────
    protected override void Awake()
    {
        base.Awake();

        Agent = GetComponent<NavMeshAgent>();
        Agent.updateRotation = false;

        Animator = GetComponentInChildren<IAnimatable>();
        StateMachine = new StateMachine<BaseCharacter>(this);

        _commandQueue = new CommandQueue<BaseCharacter>();
        _commandQueue.Initialize(this);
        _commandQueue.OnQueueEmptied += OnCommandQueueEmptied;

        StateMachine.ChangeState(new CharacterIdleState());
        Targetable = GetComponent<Targetable>();

        _behaviorTree = BuildBehaviorTree();
    }

    // Subclasses can override Start for post-Awake boot logic.
    protected virtual void Start() { }

    protected virtual void Update()
    {
        // Player-control timeout (skipped entirely for autonomous characters).
        if (!IsAutonomous && _isPlayerControlled)
        {
            _playerControlTimer -= Time.deltaTime;
            if (_playerControlTimer <= 0f)
            {
                _isPlayerControlled = false;
                TryTickBehaviorTree();
            }
        }

        _commandQueue.Tick(Time.deltaTime);
        StateMachine.Tick(Time.deltaTime);


        // Tick behavior tree periodically.
        // For autonomous characters, always tick regardless of player-control state.
        bool shouldTick = IsAutonomous || !_isPlayerControlled;
        if (shouldTick && _behaviorTree != null)
        {
            _behaviorTreeTimer += Time.deltaTime;
            if (_behaviorTreeTimer >= behaviorTreeTickInterval)
            {
                _behaviorTreeTimer = 0f;
                TryTickBehaviorTree();
            }
        }
    }


    private void OnCommandQueueEmptied()
    {
        if (IsAutonomous || !_isPlayerControlled)
            TryTickBehaviorTree();
    }

    private void TryTickBehaviorTree()
    {
        if (_behaviorTree == null) return;
        if (!_commandQueue.IsEmpty()) return;

        // For player-controlled characters, only tick from idle.
        // For autonomous characters (enemies), tick from idle OR seek —
        // so recovery works even if seek falls back without going through idle.
        if (!IsAutonomous && StateMachine.CurrentState is not CharacterIdleState)
            return;

        // Autonomous: only tick if not already in an active enemy state.
        if (IsAutonomous)
        {
            var state = StateMachine.CurrentState;
            if (state is CombatAttackState)
                return; // already doing something — don't interrupt
        }

        _behaviorTree.Tick(this);
    }

    // ── ICommandable ──────────────────────────────────────────────────────

    public virtual void GiveCommand(ICommand<BaseCharacter> command)
    {
        _isPlayerControlled = true;
        _playerControlTimer = playerControlTimeout;

        if (StateMachine.CurrentState is CharacterRestingState restingState)
        {
            restingState.ForceExit(this);
            _commandQueue.GiveCommand(command);
            return;
        }

        // Interrupt an in-progress attack (relevant for player-commandable
        // combatants like heroes; never hit for enemies, which don't call this).
        if (StateMachine.CurrentState is CombatAttackState)
        {
            StateMachine.ChangeState(new CharacterIdleState());
            _commandQueue.GiveCommand(command);
            return;
        }

        if (StateMachine.CurrentState is CharacterHarvestingState)
        {
            StateMachine.ChangeState(new CharacterIdleState());
            _commandQueue.GiveCommand(command);
            return;
        }

        _commandQueue.GiveCommand(command);
    }

    public void GiveAutonomousCommand(ICommand<BaseCharacter> command)
        => _commandQueue.QueueCommand(command);

    public void QueueCommand(ICommand<BaseCharacter> command)
        => _commandQueue.QueueCommand(command);

    public void ClearCommands()
        => _commandQueue.Clear();

    // ── Movement ──────────────────────────────────────────────────────────

    public void SetDestination(Vector3 destination)
    {
        if (!Agent.enabled || !Agent.isOnNavMesh) return;
        TargetPosition = destination;
        Agent.isStopped = false;
        Agent.SetDestination(destination);
    }

    public void StopMoving()
    {
        Agent.ResetPath();
    }

    public void ResetPath() => Agent.ResetPath();

    protected override List<BaseStat> BuildStatAssetList() => base.BuildStatAssetList();

    public void GoHome(HouseStructure home)
    {
        if (GetStatValue(CommonStats.StaysOutAtNight) > 0)
        {
            return;
        }
        InterruptCurrentActivity();
        ClearCommands();
        _isPlayerControlled = true;
        _playerControlTimer = float.MaxValue;
        _commandQueue.GiveCommand(new MoveCommand(home.EnterPosition, 1f));
        _commandQueue.QueueCommand(new EnterHouseCommand(home));
    }

    public void LeaveHome(HouseStructure home)
    {
        _isPlayerControlled = false;
        _playerControlTimer = 0f;
        StateMachine.ChangeState(new CharacterIdleState());
        _commandQueue.GiveCommand(new ExitHouseCommand(home));
    }

    private void InterruptCurrentActivity()
    {
        if (StateMachine.CurrentState is CharacterHarvestingState)
        {
            StateMachine.ChangeState(new CharacterIdleState());
            return;
        }
        if (StateMachine.CurrentState is CharacterRestingState restingState)
        {
            restingState.ForceExit(this);
            return;
        }
        if (StateMachine.CurrentState is CharacterCarryState)
        {
            if (this is GathererCharacter gatherer && gatherer.IsCarrying)
                gatherer.DetachItem();
            StateMachine.ChangeState(new CharacterIdleState());
            return;
        }
        if (StateMachine.CurrentState is CharacterPickupState)
        {
            StateMachine.ChangeState(new CharacterIdleState());
            return;
        }
    }


    // Subscribed by HeroDiedState; mirror of Tower.HandleDayNightChanged
    public void HandleDayNightChanged(TimeOfDay timeOfDay)
    {
        if (timeOfDay == TimeOfDay.Day)
        {
            Revive();
        }
    }

    private void Revive()
    {
        SetStatBaseValue(CommonStats.Health, GetStatValueSafe(CommonStats.Health));

        // Reset IsAlive so the registry sees it again
        var targetable = GetComponent<EntityTargetable>();
        if (targetable != null) targetable.ResetAlive();

        StateMachine.ChangeState(new CharacterIdleState());
    }
}