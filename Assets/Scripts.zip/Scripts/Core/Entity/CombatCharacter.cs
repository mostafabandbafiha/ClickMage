// CombatCharacter.cs � shared base for anything that can target, seek, and attack.
// EnemyCharacter and HeroCharacter both derive from this so the attack pipeline
// (MoveToTargetCommand, AttackCommand, CombatAttackState, AttackSeekBehaviorNode)
// is written once and works for both factions.
using UnityEngine;

public abstract class CombatCharacter : BaseCharacter
{
    [SerializeField] private Faction _targetFaction;

    public Targetable CurrentTarget { get; set; }
    public Faction TargetFaction => _targetFaction;

    protected override void Awake()
    {
        base.Awake();
    }

    public Targetable FindNearestTarget()
    {
        if (TargetRegistry.Instance == null) return null;
        return TargetRegistry.Instance.GetNearest(_targetFaction, transform.position);
    }

    /// <summary>Called by CombatAttackState when the attack animation hit-frame fires.</summary>
    public virtual void OnAttack() { }
}