﻿// GoblinScavenger.cs — owns everything specific to goblins
using ClickMage.Stats;
using deVoid.Utils;
using System.Collections.Generic;
using UnityEngine;

public class GoblinScavenger : EnemyCharacter
{
    [SerializeField] private EnemyData _data;
    [SerializeField] private GameObject _gravePrefab;

    [Header("Stats")]
    [SerializeField] private BaseStat attackPower;
    [SerializeField] private BaseStat attackRange;


    protected override void Awake()
    {
        base.Awake();
        if (_data != null) Agent.speed = _data.moveSpeed;
    }

    protected override BehaviorTree<BaseCharacter> BuildBehaviorTree()
    {
        return new BehaviorTree<BaseCharacter>(
            new SelectorNode<BaseCharacter>(
                new AttackSeekBehaviorNode()
            )
        );
    }

    public override void OnAttack()
    {
        if (CurrentTarget == null || !CurrentTarget.IsAlive) return;
        CurrentTarget.TakeDamage(GetStatValue(CommonStats.Damage), this);
    }


    protected override List<BaseStat> BuildStatAssetList()
    {
        var list = base.BuildStatAssetList();
        if (attackPower != null) list.Add(attackPower);
        if (attackRange != null) list.Add(attackRange);
        return list;
    }

    public override void Die(DeathCause cause)
    {
        if (cause == DeathCause.KilledByCommander)
        {
            if (_gravePrefab != null)
                Instantiate(_gravePrefab, transform.position, Quaternion.identity);
        }
        else
        {
            foreach (var slot in Inventory.Slots)
            {
                if (slot.IsEmpty) continue;
                Signals.Get<ItemDroppedToWorldSignal>().Dispatch(new ItemDroppedToWorldData
                {
                    Stack = slot.Stack,
                    WorldPosition = transform.position + Vector3.up * 0.5f,
                    DropRadius = 1f
                });
            }
        }

        base.Die(cause); // fires OnDeath + Destroy
    }
}