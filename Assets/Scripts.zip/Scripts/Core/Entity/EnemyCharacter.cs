﻿// EnemyCharacter.cs — clean abstract base, no assumptions about behavior
using UnityEngine;
public abstract class EnemyCharacter : CombatCharacter
{
    public enum DeathCause { KilledByCommander, KilledByPlayer }

    public event System.Action<EnemyCharacter> OnDeath;

    protected override bool IsAutonomous => true;

    protected override void Awake()
    {
        base.Awake();
    }

    // Subclasses set their own speed, BT, stats — no assumptions here

    // Subclasses override to define what dying means for them
    public virtual void Die(DeathCause cause)
    {
        OnDeath?.Invoke(this);
        Destroy(gameObject);
    }
}